package top.jxnu;

import java.util.Map;

public class MyXy {

    public String id;

    public String method;

    public Map<String,Object> params;

    @Override
    public String toString() {
        return "MyXy{" +
                "id='" + id + '\'' +
                ", method='" + method + '\'' +
                ", params=" + params +
                '}';
    }
}
