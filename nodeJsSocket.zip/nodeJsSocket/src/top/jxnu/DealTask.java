package top.jxnu;

import com.google.gson.Gson;
import top.itreatment.net.bean.CommonBean;
import top.itreatment.net.core.impl.ChooseSeatClientImpl;
import top.itreatment.net.res.Resource;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.Socket;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class DealTask implements Runnable {


    private static BufferedReader br;
    private Socket socket;
    private InputStream is;
    private OutputStream os;
    ChooseSeatClientImpl chooseSeatClient;
    private Map<String, Method> methodMap;

    public static DealTask dealSocket(Socket socket) throws IOException {
        DealTask dealTask = new DealTask();
        dealTask.socket = socket;
        dealTask.is = socket.getInputStream();
        dealTask.os = socket.getOutputStream();
        br = new BufferedReader(new InputStreamReader(dealTask.is));

        dealTask.chooseSeatClient = new ChooseSeatClientImpl();
        dealTask.methodMap = new HashMap<>();
        Method[] methods = ChooseSeatClientImpl.class.getMethods();
        for (Method method : methods) {
            String name = method.getName();
            dealTask.methodMap.put(name, method);
        }
        return dealTask;
    }


    @Override
    public void run() {
        Gson gson = new Gson();
        while (true) {
            try {
                String jsonStr = br.readLine();
                MyXy myXy = gson.fromJson(jsonStr, MyXy.class);
                if (myXy == null || myXy.method == null) continue;
                if ("exit".equalsIgnoreCase(myXy.method)) break;


                CommonBean commonBean = (CommonBean) dealMethod(myXy);
                commonBean.setMsg(myXy.id);
                String responseText = gson.toJson(commonBean);

                os.write(responseText.getBytes("utf-8"));
                os.write("\n".getBytes("utf-8"));
                os.flush();
            } catch (IOException e) {
                e.printStackTrace();
                break;
            }
        }
        close();
    }

    private Object dealMethod(MyXy myXy) {

        Method method = methodMap.get(myXy.method);
        if (method == null) {
            return new CommonBean(Resource.FAIL, "方法没有找到");
        }

        int parameterCount = method.getParameterCount();

        Object[] objects = new Object[parameterCount];
        for (int i = 1; i <= parameterCount; i++) {
            String key = String.valueOf(i);
            if (myXy.params != null && myXy.params.get(key) != null) {
                Object o = myXy.params.get(key);
                objects[i - 1] = o;
            }
        }
        Object com;
        try {
            System.out.println("原始数据:" + myXy.toString());
            System.out.println("执行方法:" + method.getName() + ",参数是:" + Arrays.asList(objects));
            com = method.invoke(chooseSeatClient, objects);
        } catch (IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
            com = new CommonBean(Resource.ERROR, "方法执行错误");
        }
        return com;
    }

    private void close() {
        try {
            br.close();
            os.close();
            is.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
