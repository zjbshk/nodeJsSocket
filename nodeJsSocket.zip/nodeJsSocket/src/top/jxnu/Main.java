package top.jxnu;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Main {


    private static int port = 8024;
    private static ServerSocket serverSocket;

    public static void main(String args[]) {
        initPropertis();
        launchServer();
        runServer();
    }

    private static void launchServer() {
        try {
            serverSocket = new ServerSocket(port);
            System.out.println("服务器启动成功");
        } catch (IOException e) {
            System.out.println("启动服务器Socket失败");
        }
    }

    private static void runServer() {
        try {
            System.out.println("服务器进入等待访问状态");
            Socket socket = serverSocket.accept();
            DealTask dealTask = DealTask.dealSocket(socket);
            Thread thread = new Thread(dealTask);
            thread.setPriority(Thread.MAX_PRIORITY);
            thread.start();
            System.out.println("开始提供服务");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void initPropertis() {

    }
}
